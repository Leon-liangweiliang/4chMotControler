#ifndef __ABENCODER_H
#define __ABENCODER_H


extern u8 ABEncoderDir, ABEncoderStep;
void ReadABOpticalEncoder(void);

#endif

