#ifndef __PWM_H
#define __PWM_H
#include "stc8gxx.h"

void PWMInit();
//void SetPwmDuty(u8 dutypre);
void StopPwm();
void BeginPwm();


#endif 


