#ifndef __UUID_H
#define __UUID_H

extern uint8_t UUDIERROR;

uint8_t CmpDataFlashUuid(void);

#endif

